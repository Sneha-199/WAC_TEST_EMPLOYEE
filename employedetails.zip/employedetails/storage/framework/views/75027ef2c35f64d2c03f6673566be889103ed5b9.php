<ul class="navbar-nav sidebar sidebar-light accordion" id="accordionSidebar">
    <a class="sidebar-brand d-flex align-items-center " href="#">

        <div class="sidebar-brand-text mx-3">EMPLOYEE DETAILS</div>
    </a>
    <!-- <hr class="sidebar-divider my-0">
    <li class="nav-item active">
        <a class="nav-link" href="#">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span></a> -->
    </li>
    <hr class="sidebar-divider my-0">
    <li class="nav-item active">
        <a class="nav-link" href="#">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>VIEW EMPLOYEE</span></a>
    </li>
    <hr class="sidebar-divider">
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('addEmployee')); ?>">
            <!-- <i class="fas fa-fw fa-chart-area"></i> -->
            <img src="https://img.icons8.com/cute-clipart/50/000000/add.png"/>
            <span>Manage Employee</span>
        </a>
    </li>


    <hr class="sidebar-divider">

</ul>
<?php /**PATH C:\xampp\htdocs\employedetails\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>